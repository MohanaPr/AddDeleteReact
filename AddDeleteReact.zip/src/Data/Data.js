import React from 'react';
import _ from 'lodash';
import DataItems from './DataItems';
import {Table} from "react-bootstrap";
class Data extends React.Component{
constructor(props) {
    super(props);
    this.state = {
        showEdit:false
    };
    this.onDeleteClick = this.onDeleteClick.bind(this);
    this.onEditClick = this.onEditClick.bind(this);    
  }
  componentDidMount() {
    this.props.actions.getValueAPI();
  }
onDeleteClick(item, i){ 
        var displayVal = this.props.displayVal;
        var newData= [];
        displayVal.map((data, idx) => {
            if((idx !== i)){
                newData.push(data);
            }
        })
    this.setState({showEdit:false});         
        this.props.SampleActions.getValue(newData);     
    };
onEditClick(item, i){
    this.setState({showEdit:true}); 
    this.props.SampleActions.editValue(item, i);   
    }
render(){
    const {displayVal, item, payLoad} = this.props;
    const{showEdit} = this.state;
    console.log("payLoad===", payLoad);
    return(
        <div className = "dataComp">
            {!_.isEmpty(displayVal) ? <Table striped bordered hover>
                <thead>
                        <tr>
                            <th>Name</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                </thead>
                    <tbody>
                            {displayVal.map((item, i) => {
                        return (<tr key={i}>
                                    <td> 
                                         {item} 
                                    </td>
                                    <td><button key={i} onClick={()=>this.onEditClick(item, i)}>Edit</button></td>
                                    <td><button onClick={()=>this.onDeleteClick(item, i)}>Delete</button></td>
                                </tr>)
                            }
                            )
                        }
                    </tbody>
            </Table> : <div></div>}
            
                <br/>
                {showEdit ? <DataItems displayVal = {this.props.displayVal} editName = {this.props.item} SampleActions = {this.props.SampleActions} />: ""}
        </div>
    )
}
}
export default Data;