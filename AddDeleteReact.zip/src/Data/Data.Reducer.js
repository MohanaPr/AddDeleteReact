import constants from './Data.Constants';

const initalState = {
    payLoad: []
};

function DataReducer(state = initalState, action){
    console.log("datareducer===", action.payLoad);
    switch (action.type) {
        case constants.GET_VALUEAPI:
        return Object.assign({}, state, {
            payLoad : action.payLoad
        })
        default:
        return state;
    }

};
export default DataReducer;