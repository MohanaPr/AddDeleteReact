import React from 'react';
import Data from '../Data/Data.Container';
import _ from 'lodash';
class Sample extends React.Component{
    constructor(props) {
        super(props);        
       this.state = {
        showAdd:false
    };
            this.onAddClick = this.onAddClick.bind(this);    
    }
onAddClick(){
    var typedName = [...this.props.displayVal];
    this.setState({showAdd:true});
        if((!_.isEmpty(this.name.value)) && (!_.isUndefined(typedName))){
            typedName.push(this.name.value);
            this.props.actions.getValue(typedName);     
        }
}
render(){
    const {displayVal} = this.props;
    const {showAdd} = this.state;
    return(
        <div> 
            <div className="addingDetails">
            <p className="addName">Add Name </p>
            <input name="username" type="text" ref={(name) => this.name = name}/>
            <button onClick={()=>this.onAddClick()}>Add</button><br/></div>
            {showAdd ? <Data/>: ""}
        </div>
    )
}
}
export default Sample;