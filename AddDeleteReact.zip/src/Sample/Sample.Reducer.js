import constants from './Sample.Constants';

const initalState = {
    displayVal: [],
    item:"",
    i:""
};

function SampleReducer(state = initalState, action){
    switch (action.type) {
        case constants.DISPLAY_VALUE:
        return Object.assign({}, state, {
            displayVal : action.displayVal
        })
        case constants.EDIT_VALUE:
        return Object.assign({}, state, {
            item : action.item,
            i:action.i
        })
        default:
        return state;
    }
};
export default SampleReducer;