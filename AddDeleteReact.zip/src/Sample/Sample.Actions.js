import constants from './Sample.Constants';

export function getValue(displayVal){
    console.log("action===", displayVal);
    return{
        type:constants.DISPLAY_VALUE,
        displayVal
    };
}
export function editValue(item, i){
    console.log("editValue===", item, i);
    return{
        type:constants.EDIT_VALUE,
        item,
        i
    };
}

